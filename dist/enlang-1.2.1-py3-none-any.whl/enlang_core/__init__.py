"""
EnLang Core Package
Natural English Programming Language Transpiler, Interpreter & Domain Helpers.
"""

from .transpiler import EnLangTranspiler
from .interpreter import EnLangInterpreter

__version__ = "1.2.1"
__all__ = ["EnLangTranspiler", "EnLangInterpreter"]
